class SkolasAptauja:
    def __init__(self):
        self.jautajumi = []
        self.atbildes = []

    def pievienot_jautajumu(self, jautajums, pareiza_atbilde):
        self.jautajumi.append(jautajums)
        self.atbildes.append(pareiza_atbilde)

    def parbaudit_atbildi(self, jautajuma_nr, atbilde):
        if atbilde.lower() == self.atbildes[jautajuma_nr].lower():
            return 10  
        else:
            return -5  

    def izveidot_aptauju(self):
        print("Sveiki! Tagad būs neliela aptauja par mūsu skolu, jautājumi būs dažādi, bet tikai saistībā ar skolu.")
        print("Un šeit ir daži noteikumi.")
        print("1. Pavisam būs 10 jautājumi.") 
        print("2. Par katru pareizu atbildi tu saņemsi 10 punktus.")
        print("3. Par nepareizo atbildi tev atņems 5 punktus.")
        print("4. Tavs punktu skaits nevar būt lielāks par 100 un mazāks par 0.")
        punkti = 0
        for i in range(len(self.jautajumi)):
            print(f"{i+1}. jautājums: {self.jautajumi[i]}")
            atbilde = input("Ievadiet atbildi: ")
            punkti += self.parbaudit_atbildi(i, atbilde)
            if punkti < 0:
                punkti = 0  
            if self.parbaudit_atbildi(i, atbilde) == 10:
                print("Pareiza atbilde!")
            else:
                print("Nepareizi, pacenties atbildet pareizi nākamo!")
            print(f"Aktuālais punktu skaits: {punkti}\n")
        print("Aptauja beigusies. Jūsu kopējais punktu skaits:", punkti)

skolas_aptaujas = SkolasAptauja()

skolas_aptaujas.pievienot_jautajumu("Kurā datumā skolēni iet uz skolu?", "1. septembrī")
skolas_aptaujas.pievienot_jautajumu("Cik vierzienu ir mūsu skolā? 1, 2, 3 vai 4?", "3")
skolas_aptaujas.pievienot_jautajumu("Kurā stāvā atrodas 307. kabinets? 1, 2, 3 vai 4?", "3")
skolas_aptaujas.pievienot_jautajumu("Kurā kabinetā notiek ķimijas stundas? 124, 312, 413, 213, 212", "213")
skolas_aptaujas.pievienot_jautajumu("Cik reizes skan zvas pirms stunda sāksies?", "2")
skolas_aptaujas.pievienot_jautajumu("Cik skolēnu ir mūsu klasē? 29, 30, 31, 32?", "30")
skolas_aptaujas.pievienot_jautajumu("Pēc kuras stundas 10.b. iet pusdienās? 5, 6 vai 7?", "6")
skolas_aptaujas.pievienot_jautajumu("Kā sauc 10.b. klases audzinātāju?", "Tauriņa Daina")
skolas_aptaujas.pievienot_jautajumu("Cik virzienu vienlaikus ir mūsu klasē?", "2")
skolas_aptaujas.pievienot_jautajumu("Cik korpusu ir mūsu skolai? 1 vai 2?", "2")

def gataviba(): 
    spelat = input("Vai vēlaties sākt aptauju? (jā/nē): ")
    if spelat.lower() == "jā":
        
        skolas_aptaujas.izveidot_aptauju()
    elif spelat.lower() == "nē":
        
        print("Jūs izvēlējāties nepiedalīties aptaujā. Paldies par uzmanību!")
    else:
        gataviba()

gataviba()