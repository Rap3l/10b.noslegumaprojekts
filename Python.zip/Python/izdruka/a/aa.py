x = int(input())
if x < 35:
    print("vai nav auksti?")
elif x > 37:
    print(" esi slims")
else:
    print("viss ok")