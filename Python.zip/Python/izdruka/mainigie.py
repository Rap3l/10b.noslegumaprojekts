pirmais = 2
print(type(pirmais))
pirmais = ["Ringo", "Privet"]
print(type(pirmais))

a = 5
print(a)
print(a + a)
a = a + a
print(a)
type(a) #neaizmirst print
a = 30.1
type(a)

mani_ienakumi = 100
nodoklis = 0.1
maniNodokli = mani_ienakumi * nodoklis
print(maniNodokli)

print("Ievadi vārdu: ")
x = input()
print("Tavs ievadītais vārds ir " + x)