print(True)
print(type(False))


print(3 > 4)
print(2 == 2)
print(2 * 2 == 4) #vienāds
print(2 * 2 != 5) #nav vienāds
a = 50
b = 4
c = 4
print(a > b, b != c, c == a)
print(a >= b, b < c, c <= a)

print("////")

print(True and True)
a = 5
b = 10
print(a > 5 and b > 20)
print(a >= 5 and b > 9)
print(a >= 5 or b > 20)
print(a >= 5 or b > 9)
print(not a > 5)
print(a > 4 or b > a or b > 10)