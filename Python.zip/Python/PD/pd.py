#1uzd

myString = "abcdefghijklmnoprstuvz"
print(myString[10:13])

#2uzd

a = input("Lūdzu ievadi tekstu")
x = a.upper()
print(x)

#3uzd

q = input()
w = input()
if q > w:
    print(f"Skaitlis {q} ir lielāks par skaitli {w}")
elif w > q:
    print(f"Skaitlis {w} ir lielāks par skaitli {q}")
else:
    print(f"Skaitlis {w} ir vienāds ar skaitli {q}")

#4uzd

myList = [5, 7, 6, 8, 25, -4, 3]
result = 1
for reiz in myList:
    result *= reiz
print (result)

#5uzd

def klase(numurs="tu"):
    print(f"Es macos {numurs} klase")
klase(input())


