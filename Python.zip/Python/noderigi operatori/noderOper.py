#vienkarsi piepildit list ar elementiem
saraksts = list(range(0,11,2))
print(saraksts)

#enumerate - parada indeksus tuple forma
vards = "pasaule"
for i in enumerate(vards):
    print(i)

#atpakot tuples
for index,burts in enumerate(vards):
    print(index)
    print(vards)
    print("\n")

#izmanto zip, sapako vairakus list ka tuple
my_list = [1,2,3]
my_list2 = ["a", "b", "c"]
for i in zip(my_list, my_list2):
    print(i)

my_list3 = [1,2,13.4,7,8]
for i in zip(my_list2, my_list, my_list3):
    print(i)

#saliek visu vienā list
print(list(zip(my_list, my_list2, my_list3)))

#izmanto in, lai noskaidrotu vai objektā ir atrodams mekletajs
print("x" in [1,2,3])
print(2 in [1,2,3])
print("a" in "pasaule")
print("atslega2" in {"atslega1" :256})
d = {"atslega1":256}
print(256 in d.keys)
print(256 in d.values())

#min un max
my_list33 = [10,20,30,40,4.6]
print(min(my_list33))
print(max(my_list33))
