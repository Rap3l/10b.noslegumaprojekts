#videjais(3,9,4,9,5,6)
#videjais(7,8,7)

def videjais(*skaitli):
    return sum(skaitli)/len(skaitli)
print(videjais(3,9,4,9,5,6))
print(videjais(7,8,7))