import random 
glazites = ["🥛","🥛","⚽"]

 
def sajauc(glazites):
    shuffle(glazites)
    return glazites
 
#print(sajauc(glazites))
 
# pajauta minejumu
def mans_minejums():
    minejums = ""
    while minejums not in ["1","2","3"]:
        minejums = input("Kurā glazīte ir bumbiņa (ievadi 1,2 vai 3)?:")
    return int(minejums)
#print(mans_minejums())
 
# parbauda vai minejums ir pareizs
def parbaudi_minejumu(glazites, minejums):
    if glazites[minejums-1]=="⚽":
        print("Uzvarēji!")
        print(glazites)
    else:
        print("Zaudēji")
        print(glazites)
 
# pa soliem izsauc visas funkcijas
       
# sajauc glazites
sajauktais = sajauc(glazites)
 
# speletaja minejums
speletaja_minejums = mans_minejums()
 
# parbauda speletaja minejumu
parbaudi_minejumu(sajauktais, speletaja_minejums)