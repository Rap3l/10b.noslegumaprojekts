from random import randint,shuffle
glaze = ["🥛","🥛","⚽"]
print(glaze)

def sajauc(glaze):
    shuffle(glaze)
    return glaze

print(sajauc(glaze))

#pajautā minējumu
def mans_minejums():
    minejums = ""
    while minejums not in [1,2,3]:
        minejums = input("Kurā glāzīē ir bumbiņa (ievadi 1, 2 vai 3)?:")
    return int(minejums)

print (mans_minejums())