# importē bibliotēkas
from random import randint,shuffle

print(randint(1,100))
saraksts = [1,2,3,4,5]
shuffle(saraksts)
print(saraksts)

# metode try except - pārbauda vai tiek ievadīts prasītais
while True:
    x = input("Ievadi veselu skaitli:")
    try:
        if int(x):
            break
    except:
        print(f"{x} nav vesels skaitlis")

#parbaudu var ir ivadits prasitais
x = input("ievadi 1, 2 vai 3:")
while x not in ["1", "2","3"]:
    x = input("ievadi 1, 2 vai 3:")

glaze = ["🥛","🥛","⚽"]

def sajauc(glaze):
    shuffle(glaze)
    return glaze

print(sajauc(glaze))

#pajautā minējumu
def mans_minejums():
    minejums = ""
    while minejums not in [1,2,3]:
        minejums = input("Kurā glāzīē ir bumbiņa (ievadi 1, 2 vai 3)?:")
    return int(minejums)

print (mans_minejums())

#pātbauda minejumu
