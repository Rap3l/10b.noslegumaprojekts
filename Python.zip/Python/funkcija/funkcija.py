#/////1

def izdruka():
    print("Sveika, pasaule!")

izdruka()

#/////2

def maize(ko_likt):
    print(f"Šī sviestmaize ir ar {ko_likt}")

maize("sieru")
maize("desu")

#/////3

def patiess(atbilde):
    if atbilde ==True:
        return "Labdien"
    else:
        return "Uz redzešanos!"
print(patiess(True))
print(patiess(False))

#/////4

def skaitli(x, y):
    if x>y:
        return True
    else:
        return False
print(skaitli(5 , 6))


