d = {"k1": 11, "k2": 12, "k3": 13}
for elements in d:
    print(elements)

for elements in d.items():
    print(elements)

for atslega, vertiba in d.items():
    print(vertiba)
