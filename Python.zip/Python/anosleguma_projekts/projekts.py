#punkti
punkti = 0
#1teksts
print("Sveiki! Tagad būs neliela aptauja par mūsu skolas kabinetiem, paskatīsimies kā tu tos zini")
print("Noteikumi")
print("Pavisam būs 10 jautājumi, pavisam var nopenīt 100 punktus.") 
print("Par katru pareizu atbildi tu saņemsi 10 punktus, par nepareizo -5, mazāk par 0 nevar būt")

#1 jautājums