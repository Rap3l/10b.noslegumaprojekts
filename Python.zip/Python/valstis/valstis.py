from random import random, randint
valstis = {
            "Albānija": "Tirāna",
            "Andora": "Andora la Vella",
            "Armēnija": "Yerevan",
            "Austrija": "Vīne",
            "Azerbaidžāna": "Baku",
            "Baltkrievija": "Minsk",
            "Beļģija": "Brisele",
            "Bosnija un Hercegovina": "Sarajevo",
            "Bulgārija": "Sofija",
            "Horvātija": "Zagreb",
            "Kipra": "Nikosija",
            "Čehija": "Prāga",
            "Dānija": "Kopenhāgena",
            "Igaunija": "Tallina",
            "Somija": "Helsinki",
            "Francija": "Parīze",
            "Gruzija": "Tbilisi",
            "Vācija": "Berlīne",
            "Grieķija": "Atēnas",
            "Ungārija": "Budapešta",
            "Īslande": "Reykjavik",
            "Īrija": "Dublina",
            "Itālija": "Roma",
            "Kazahstāna": "Nur-Sultan",
            "Kosova": "Priština",
            "Latvija": "Rīga",
            "Lietuva": "Vilnius",
            "Luksemburga": "Luksemburga",
            "Ziemeļmakedonija": "Skopje",
            "Malta": "Valeta",
            "Moldova": "Kišiņeva",
            "Monako": "Monako",
            "Melnkalne": "Podgorica",
            "Nīderlande": "Amsterdama",
            "Norvēģija": "Oslo",
            "Polija": "Varšava",
            "Portugāle": "Lisabona",
            "Rumānija": "Bukareste",
            "Krievija": "Maskava",
            "Sanmarīno": "Sanmarīno",
            "Serbija": "Belgrada",
            "Slovākija": "Bratislava",
            "Slovēnija": "Ljubljana",
            "Spānija": "Madride",
            "Zviedrija": "Stokholma",
            "Šveice": "Bern",
            "Turcija": "Ankara",
            "Apvienotā Karaliste": "Londona",
            "Vatikāns": "Vatikāns",
}
atslegas = list(valstis.keys())

skaits = 0
PareizasAtbildes = 0

while True:
    gadijums = randint(0, len(atslegas)-1)
    galvaspilseta = input(f"Kas ir {atslegas[gadijums]} galvaspilsēta?")

    if galvaspilseta.lower() == "q":
        print("Paldies par spēli!😉")
        break
    
    elif galvaspilseta.capitalize() == valstis[atslegas[gadijums]]:
        print("Pareizi")
        PareizasAtbildes += 1
    else:
        print("Nepareizi")
    skaits += 1

print(f"Tu pareizi atbildēji uz {PareizasAtbildes} no {skaits}")




