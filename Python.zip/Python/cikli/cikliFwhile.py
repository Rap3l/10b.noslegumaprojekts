i = 0
while i <= 5:
    print("labi")
    i += 1 #i=i+1
print("i tagad ir", i)

j = 0 #tipisks cikla mainīgais
while j < 5:
    print("Nr.", j)
    j += 1



i = 20
while True: # cikls darbosies, kamēr nosacījums būs patiess
    if i > 26:
        break # pārtrauc ciklu, ja nosacījums nepatiess
    print("i ir", i)
    i += 2

