skaitli = []
i = 0
while i <= 100:
    skaitli.append(i)
    i += 1
    if i % 5 == 0 and i % 7 == 0:
        print("FizzBuzz" , end = " ")
    elif i % 7 == 0:
        print("Buzz" , end = " ")
    elif i % 5 == 0:
        print("Fizz" , end = " ")
    else:
        print(i , end = " ")

       

