a = int(input("ievadi augstumu un platumu"))
i = 0
while i < a:
    print("*" * a)
    i += 1
    