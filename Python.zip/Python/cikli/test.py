a = int(input())
b = int(input())
for skaitlis in range(a - 1,b):
    if a < b:
        print( skaitlis + 1 , end = " ")
    else:
       while a < b:
           print((a , b))
           (a , b) -= 1

