mainigais = [1,2,3] #piem., list, tuple, string vai dictionary
for elements in mainigais:
    print(elements)

for skaitlis in range(15):
    print(skaitlis)

for skaitlis in range(4, 15):
    print(skaitlis)

for skaitlis in range(4, 15, 3):
    print(skaitlis)

print("///////////////////////")

mylist = [1,2,3,4,5,6,7,8,9,10,11,12]
for skaitlis in mylist:
    if skaitlis % 2 == 0:
        print(skaitlis)
    else:
        print(f"nepāra skailis: {skaitlis}")

print("///////")



