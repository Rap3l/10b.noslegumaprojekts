x = input("Ievadi savu vārdu: ")
print(f"{x[::-1].capitalize()}. Pamatigs juceklis, vai ne {x[0]}?")





