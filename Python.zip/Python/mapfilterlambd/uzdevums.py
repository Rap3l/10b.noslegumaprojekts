#1uzdevums
vardi = ["roka", "sēnes", "konfekte", "programma", "puķupods", "kaza", "suns", "skola"]
def atlasit_4(saraksts):
    atlasi = [vards for vards in saraksts if len(vards) == 4]
    return atlasi

resultats = atlasit_4(vardi)
print(resultats)

#2
skaitli = [2, 30, 8, 50, 14, 9, 6, 67, 3.5, 36, 114]
mazaki30 = list(filter(lambda x: x < 30, skaitli))
print(mazaki30)

#3
vardi = ["roka", "sēnes", "konfekte", "programma", "puķupods", "kaza", "suns", "skola"]
otradi = lambda vardi: vardi[::-1]
print(otradi(vardi))
 


    