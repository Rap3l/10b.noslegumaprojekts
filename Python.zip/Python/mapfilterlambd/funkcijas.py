#map
#funckija kura rekina skaitli kvadratā
def kvadrati(sk):
    return sk**2


print(kvadrati(5))

skaitli = [1,2,3,4,5,6,30]
print(map(kvadrati,skaitli)) #nedarbojas nepieciešama literacija

#1variants
for i in map(kvadrati,skaitli):
    print(i, end="")
print()

#2 variants
print(list(map(kvadrati, skaitli)))

#funckija kura nosaka var varda garums ir para vai nepara skaitlis
kautkascits = ["Ieva","Jānis","Katrīna"]


def garums(vards):
    if len(vards) % 2 == 0:
        return "Para skaitlis"
    else:
        return "Nepara skaitlis"

print(garums("anastasija"))
print(list(map(garums, kautkascits)))



#funckija kura nosaka un uzraksta varda garumu
def varda_garums(vards):
    return len(vards)


print(list(map(varda_garums, kautkascits)))


#filter
#funkcija kura nosaka vai dotais skaitlis ir nepara vai nepara
def paris(skaitlis):
    return skaitlis % 2 == 0


print(paris(2))
skaitli = [25,36,52,45,87,14]
print(list(filter(paris,skaitli)))

for i in filter(paris, skaitli):
    print(i, end = "")
print()
#aprekinat rinka garumu
# 3.14*r*r


def r_lauk(r):
    return 3.14 * r**2 > 50


print(r_lauk(5))
radiusi = [1,6,0.25,14]

print(list(filter(r_lauk, radiusi)))

#labda
#funckija kura rekina skaitli kvadrata
#def kvadratiL(sk)
#    rez = sk**2
#    return rez

#saisina funkciju
# def kvadratL(sk):
#      return sk**2


def kvadratiL(sk):
    return sk**2


print(kvadratiL(5))

#nonem funkcijas definiciju un aizstaj ar lambda

kvadr = lambda sk: sk**2
print(kvadr(6))

#sakbinē ar map
skaitli = [25,36,52,45,84,17]
print(list(map(lambda sk: sk**2, skaitli)))

#sakombine ar filtre
print(list(filter(lambda sk: sk % 2 == 0, skaitli)))
