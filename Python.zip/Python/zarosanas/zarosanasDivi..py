def klase(numurs="tu"):
    print(f"Es macos {numurs} klase")
klase(input())