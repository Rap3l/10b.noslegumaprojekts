a = int(input("ievadi skaitli"))
if a > 0:
    print(f" skaitlis {a} ir pozitīvs. ")
elif a == 0:
    print(f" skaitlis {a} ir nulle. ")
else:
    print(f"Skaitlis {a} ir negatīvs. ")